/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade3;

import javax.swing.JOptionPane;

/**
 *
 * @author daniel.wrtavares
 */
public class Atividade3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String escolha = JOptionPane.showInputDialog("Digite uma opção:\n1 - opcao\n2 - opcao2\n3 - sair");

        // Usei o .equals pq achei usual professor, espero que nao seja um problema.
        if (escolha.equals("1")) {
            JOptionPane.showMessageDialog(null, "Boa escolha");
        } else if (escolha.equals("2")) {
            JOptionPane.showMessageDialog(null, "Segunda opcao, boa escolha haha");
        } else if (escolha.equals("3")) {
            JOptionPane.showMessageDialog(null, "tchau entao :(");
        } else {
            JOptionPane.showMessageDialog(null, "Opçao invalida. Tente novamente.");
        }
    }
    
}
