/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade;

import javax.swing.JOptionPane;

   

/**
 *
 * @author daniel.wrtavares
 */
public class Atividade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String usuario = JOptionPane.showInputDialog(null, "Digite seu nome!!");
       String CPF = JOptionPane.showInputDialog(null, "Digite o seu CPF");
  JOptionPane.showMessageDialog(null,"seu nome é "+ usuario +" e seu CPF é " + CPF);
        
       
       
       
       
        
                
        
    }
    
}
